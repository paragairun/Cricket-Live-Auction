# Add/Update these functions in backend/app/services/auction_service.py

async def undo_last_bid(event_id: int, auction_player_id: int, db: AsyncSession) -> dict:
    """Reverts the latest bid on the active player (Bid Down)."""
    ap_res = await db.execute(select(AuctionPlayer).where(AuctionPlayer.id == auction_player_id))
    ap = ap_res.scalar_one_or_none()
    if not ap or ap.status != PlayerAuctionStatus.active:
        raise ValueError("Player is not active")

    bids_res = await db.execute(
        select(Bid)
        .where(Bid.event_id == event_id, Bid.auction_player_id == auction_player_id)
        .order_by(Bid.id.desc())
    )
    bids = bids_res.scalars().all()
    if not bids:
        raise ValueError("No bids to undo")

    # Delete the latest bid
    latest_bid = bids[0]
    await db.delete(latest_bid)

    if len(bids) > 1:
        prev_bid = bids[1]
        ap.current_bid = prev_bid.amount
        ap.current_bidder_id = prev_bid.captain_id
    else:
        ap.current_bid = ap.base_price
        ap.current_bidder_id = None

    await db.commit()
    await manager.broadcast(event_id, {
        "type": "new_bid",
        "auction_player_id": ap.id,
        "amount": ap.current_bid,
        "captain_id": ap.current_bidder_id,
    })
    return {"current_bid": ap.current_bid, "current_bidder_id": ap.current_bidder_id}


async def edit_current_bid(event_id: int, auction_player_id: int, new_amount: int, db: AsyncSession) -> dict:
    """Manually edits the current bid amount on the active player (Pencil Edit button)."""
    ap_res = await db.execute(select(AuctionPlayer).where(AuctionPlayer.id == auction_player_id))
    ap = ap_res.scalar_one_or_none()
    if not ap or ap.status != PlayerAuctionStatus.active:
        raise ValueError("Player is not active")
    if new_amount < 0:
        raise ValueError("Bid amount cannot be negative")

    if ap.current_bidder_id is not None:
        team_res = await db.execute(
            select(Team).where(Team.event_id == event_id, Team.captain_id == ap.current_bidder_id)
        )
        team = team_res.scalar_one_or_none()
        if team and (team.budget - team.spent) < new_amount:
            raise ValueError(f"{team.name} does not have enough remaining purse ({team.budget - team.spent})")

        # Update latest bid record if present
        bids_res = await db.execute(
            select(Bid)
            .where(Bid.event_id == event_id, Bid.auction_player_id == auction_player_id)
            .order_by(Bid.id.desc())
        )
        latest_bid = bids_res.scalars().first()
        if latest_bid:
            latest_bid.amount = new_amount

    ap.current_bid = new_amount
    if ap.current_bidder_id is None:
        ap.base_price = new_amount

    await db.commit()
    await manager.broadcast(event_id, {
        "type": "new_bid",
        "auction_player_id": ap.id,
        "amount": ap.current_bid,
        "captain_id": ap.current_bidder_id,
    })
    return {"current_bid": ap.current_bid, "current_bidder_id": ap.current_bidder_id}
