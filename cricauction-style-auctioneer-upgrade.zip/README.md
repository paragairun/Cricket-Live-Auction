# Broadcast-Style Auctioneer Console Upgrade

## What Was Built (Inspired by CricAuction Live Console)
1. **Hero Player Banner**: Large player photo, jersey/pool number, name, role/stats, category badge, base price, and active bid slab increment indicator.
2. **Central Bid Counter + Pencil Edit (`✎`)**: Live bid readout with leading team indicator and a manual bid-amount override modal.
3. **Team Paddle Cards**: Displays remaining purse (`Spent / Total`), **Max Bid** (reserving minimum base price for remaining mandatory squad slots), squad count badge, and **View Squad** modal. Clicking any team card places the next slab-calculated bid immediately.
4. **Broadcast Control Dock**:
   - **New Player**: `🎲 RANDOM` and `📋 MANUAL` (with category filter pills).
   - **Bid Controls**: `↑ BID UP` (dynamic slab increment) and `↓ DOWN (UNDO)` (reverts the previous bid in DB + broadcasts over WebSocket).
   - **Hammer Actions**: Dedicated green `SOLD` and red `UNSOLD` buttons.
5. **Bottom Status Bar**: Quick drawers for `Sold`, `Unsold` (with Re-auction), `Available`, and `Teams`.

## Installation Paths
- `frontend/store/auction.ts` -> Replace existing file.
- `frontend/app/auction/[eventId]/auctioneer/page.tsx` -> Replace existing file.
- `frontend/rebuild-all.ps1` -> Place in `frontend/` and run whenever you deploy updates.
- `backend/app/schemas/auction.py`, `backend/app/api/auction.py`, `backend/app/services/auction_service.py` -> Apply the included patches for `bid-down` (undo), `bid-edit`, and `bid_slabs` + `categories` in `get_auction_state`.
