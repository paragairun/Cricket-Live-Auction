# Auctioneer Console Upgrade v2

## Fixes Included in v2
1. **Opening Bid at Base Price (`place_bid`)**: Allows the first bid on a player to equal `base_price` when `current_bidder_id` is empty (`None`), eliminating the `"Bid must be higher than current bid"` error on the first tap.
2. **Category Base Price Resolution**: Resolves each player's `base_price` from their assigned `PlayerCategory` both in `auction_service.py` (`set_next_player`, `get_auction_state`, `undo_last_bid`) and in `auctioneer/page.tsx`.
3. **Auto-Target `BID UP` Button**: `BID UP` now defaults to the current leading bidder (or first available team) if you haven't tapped a paddle yet.
4. **Accurate Max Bid Calculation**: Uses the event's minimum category/player base price to reserve funds for remaining squad slots.

## Installation
1. Copy `frontend/store/auction.ts`, `frontend/app/auction/[eventId]/auctioneer/page.tsx`, and `frontend/rebuild-all.ps1` into your `frontend/` folder.
2. Apply the updated snippets in `backend/app/schemas/auction_patch.py`, `backend/app/api/auction_patch.py`, and `backend/app/services/auction_service_patch.py` to your `backend/` files.
3. Run in PowerShell inside `frontend/`:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\rebuild-all.ps1
   ```
